<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>HR System</title>


    <!---Bootstrap -->
    <link rel="stylesheet" href="../css/bootstrap-4-3.css">
    
    <link rel="stylesheet" href="../css/bootstrap-4-5.css">

    <link rel="stylesheet" href="../css/fontawesome.css">

    <!---Style sheet-->
    <link  rel="stylesheet" href="../css/style.css">

</head>

<body>

<!-- <script src="../js/bootstrap-4-5.js"></script>-->
   

    <script src="../js/jquery-3-3.js"></script>

    <script src="../js/ajax-1-14.js"></script>

    <script src="../js/bootstrap-4-3.js"></script>
    
    <script src="../js/main.js"></script>

    <script src="../js/ajax-3-5.js"></script>


</body>

</html>