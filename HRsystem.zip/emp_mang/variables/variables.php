
<?php

//pds 
$emp_gender = "";
    $emp_civil_status ="";
    $emp_height = "(m)";
    $emp_weight = "(kg)";
    $emp_blood = "";
    $emp_citizen = "";
    $emp_citizen_chk = "";
    $emp_dual_citizen = "Indicate Country If dual Citizenship";
    $emp_resi_add ="House/Block/Lot No";
    $emp_resi_add_street = "Street";
    $emp_resi_add_subdivision = "Subdivision/Village";
    $emp_resi_add_barangay = "Barangay";
    $emp_resi_add_municipal = "Municipal/City";
    $emp_resi_add_province = "Province";
    $emp_resi_add_zipcode = "Zip Code";
    $emp_per_add ="House/Block/Lot No";
    $emp_per_add_street = "Street";
    $emp_per_add_subdivision = "Subdivision/Village";
    $emp_per_add_barangay = "Barangay";
    $emp_per_add_municipal = "Municipal/City";
    $emp_per_add_province = "Province";
    $emp_per_add_zipcode ="Zip Code";
    $emp_tel_no = "";
    $emp_mb_no = "";
    $emp_email = "";
    $emp_contact_gs = "GSIS ID No.";
    $emp_contact_pag = "PAG-IBIG ID No.";
    $emp_contact_ph = "PHILHEALTH No.";
    $emp_contact_ss = "SSS ID No.";
    $emp_contact_tin = "TIN No.";
    $emp_contact_agency = "AGENCY EMPLOYEE No.";

    $emp_sex = "";

    //family-background
    $emp_spouse_lastname = "Surname";
    $emp_spouse_firstname ="First";
    $emp_spouse_middlename = "Middle";
    $emp_spouse_extname = "Ext";
    $emp_sp_occupation = "";
    $emp_sp_employer = "";
    $emp_sp_add = "";
    $emp_sp_tel = "";
    $emp_father_lastname = "Surname";
    $emp_father_firstname = "First";
    $emp_father_middlename = "Middle";
    $emp_father_extname = "Ext";
    $emp_mother_lastname ="Surname";
    $emp_mother_firstname = "First";
    $emp_mother_middlename = "Middle";
    $emp_mother_extname = "Ext";

    $by_nature="";
    $by_birth="";


//edubackground

$ele_school_name = "";
$ele_degree = "";
$ele_from_date = "";
$ele_to_date = "";
$ele_units = "";
$ele_award = "";
$ele_graduation = "";

$sec_school_name = "";
$sec_degree = "";
$sec_from_date = "";
$sec_to_date = "";
$sec_units = "" ;
$sec_award = "";
$sec_graduation = "";

$voc_school_name = "";
$voc_degree = "";
$voc_from_date = "";
$voc_to_date = "";
$voc_units = "";
$voc_award = "";
$voc_graduation = "";


$coll_school_name = "";
$coll_degree = "";
$coll_from_date = "";
$coll_to_date = "";
$coll_units = "";
$coll_award = "";
$coll_graduation = "";

$gra_school_name = "";
$gra_degree = "";
$gra_from_date = "";
$gra_to_date = "";
$gra_units = "";
$gra_award = "";
$gra_graduation = "";

$post_school_name = "";
$post_degree = "";
$post_from_date = "";
$post_to_date = "";
$post_units = "";
$post_award = "";
$post_graduation = "";

    //civil-service 
    $type_of = "";
    $name_of_exam ="";
    $rating = "";
    $exam_date = "";
    $exam_place = "";
    $licence_no = "";
    $licence_val = "";

    //work experience

    $query = "SELECT * FROM emp_work WHERE emp_id = '$emp_id'";

    $runquery = $conn -> query($query);
    if($runquery == true){
        $rowcount=mysqli_num_rows($runquery);
        
        for($i= 0; $i <=  $rowcount ; $i++ )
        {
               
               while($data = $runquery -> fetch_assoc()){
  
                $work_from_date[$i] = $data["work_from_date"];
                $work_to_date[$i] = $data["work_to_date"];
                $work_position[$i] = $data["work_position"];
                $employer[$i] = $data["employer"];
                $monthly_sal[$i] = $data["monthly_sal"];
                $increment[$i] = $data["increment"];
                $govt_service[$i] = $data["govt_service"];
                $work_status[$i] = $data["work_status"];
        }
  
    }
  }

  /*
    $work_from_date = "";
    $work_to_date ="";
    $work_position = "";
    $employer ="";
    $monthly_sal = "";
    $increment = "";
    $govt_service_yes="";
    $govt_service_no="";
    $work_status="";
    */
    
    //voluntary works
    $name_org = "";
    $org_add ="";
    $vol_no_of_hrs = "";
    $position = "";
    $vol_from_date = "";
    $vol_to_date = "";

    //learning
    $title_of_training = "";
    $type_of_position = "";
    $no_of_hrs = "";
    $learn_from_date = "";
    $learn_to_date = "";
    $conducted_by = "";

    //references
    $emp_gov_id = "Government Issued ID";
    $emp_passport_no = "id/License/Passport No.";
    $emp_place_of_insurance = "Date/Place of Issurance";
    

    //others

  
    $condition_1 = "";
    $condition_2 = "";
    $condition_3 = "";
    $condition_4 = "";
    $condition_5 = "";
    $condition_6 = "";
    $condition_7 = "";
    $condition_8 = "";
    $condition_9 = "";
    $condition_10 = "";
    $condition_11 = "";
    $condition_12 = "";

    $condition_1_no = "";
    $condition_2_no = "";
    $condition_3_no = "";
    $condition_4_no = "";
    $condition_5_no = "";
    $condition_6_no = "";
    $condition_7_no = "";
    $condition_8_no = "";
    $condition_9_no = "";
    $condition_10_no = "";
    $condition_11_no = "";
    $condition_12_no = "";

    $condition_1_des = "If YES , please give details";
    $condition_2_des = "If YES , please give details";
    $condition_3_des = "If YES , please give details";
    $condition_4_des = "If YES , please give details";
    $condition_5_des = "If YES , please give details";
    $condition_6_des = "If YES , please give details";
    $condition_7_des = "If YES , please give details";
    $condition_8_des = "If YES , please give details";
    $condition_9_des = "If YES , please give details";
    $condition_10_des = "If YES , please give details";
    $condition_11_des = "If YES , please give details";
    $condition_12_des = "If YES , please give details";

    //special skills
/*
    for ($i = 0 ; $i < 3 ; $i++){
        
  $emp_special_skills_arr[$i]= "";
  $non_academic_arr[$i]="" ;
  $membership_arr[$i]= "" ;

    }
    */
    ?>