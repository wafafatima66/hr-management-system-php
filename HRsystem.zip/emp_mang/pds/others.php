
        <!--body section of OTHER INFORMATION-->

        <div class="container">
        <div class=" emp_profile_section2 other_info pt-4 " id="content-9">  

            <div class="container " style="width:800px;margin:auto" >

                <div class="row mt-2 mb-2" style="width:60%">
                    <p>Are you related by consanguinity or affninity to the appointing or recommending authority, or to the cheif of bureau or office or to the person who has immediate supervision over you in the office,Bureau or Department where you will be appointed.</p>
                </div>

                <div class="row mt-2 mb-2 ">
                   <div class="container ">

                        <div class="row">

                            <div class="col-lg-6">
                                <p>a.within the third degree?</p>
                            </div>

                            <div class="col-lg-6 form-inline">

                                <div class="form-check mx-sm-1 mb-2">
                                    <input class="form-check-input" type="checkbox" value="yes" name="condition_1"  <?php echo $condition_1 ;?> > 
                                    <label class="form-check-label">Yes</label>
                                </div>

                                <div class="form-check mx-sm-1 mb-2">
                                    <input class="form-check-input" type="checkbox" value="no" name="condition_1" <?php echo $condition_1_no?> >
                                    <label class="form-check-label" >No</label>
                                </div>

                                <div class="form-group mx-sm-1 mb-2">
                                    <input type="text" class="form-control" style="width:200px;"  value="<?php echo $condition_1_des?>" name="condition_1_des">
                                </div>

                            </div>


                        </div>


                        <div class="row">

<div class="col-lg-6">
    <p>b.within the fourth degree (for Local Government Unit - Career Employees)?</p>
</div>

<div class="col-lg-6 form-inline">

    <div class="form-check mx-sm-1 mb-2">
        <input class="form-check-input" type="checkbox" value="yes" name="condition_2" <?php echo $condition_2 ;?> >
        <label class="form-check-label" > Yes</label>
    </div>

    <div class="form-check mx-sm-1 mb-2">
        <input class="form-check-input" type="checkbox" value="no" name="condition_2" <?php echo $condition_2_no?> >
        <label class="form-check-label" >No</label>
    </div>

    <div class="form-group mx-sm-1 mb-2">
        <input type="text" class="form-control" style="width:200px;" value="<?php echo $condition_2_des?>" name="condition_2_des" >
    </div>

</div>


</div>



<div class="row">

<div class="col-lg-6">
    <p>Have you ever been found guilty of any administrative offense?</p>
</div>

<div class="col-lg-6 form-inline">

    <div class="form-check mx-sm-1 mb-2">
        <input class="form-check-input" type="checkbox" value="yes" name="condition_3" <?php echo $condition_3 ;?>>
        <label class="form-check-label" > Yes</label>
    </div>

    <div class="form-check mx-sm-1 mb-2">
        <input class="form-check-input" type="checkbox" value="no" name="condition_3" <?php echo $condition_3_no?> >
        <label class="form-check-label" >No</label>
    </div>

    <div class="form-group mx-sm-1 mb-2">
        <input type="text" class="form-control" style="width:200px;" value="<?php echo $condition_3_des?>" name="condition_3_des" >
    </div>

</div>


</div>



<div class="row">

<div class="col-lg-6">
    <p>Have you been criminally charged before any court?</p>
</div>

<div class="col-lg-6 form-inline">

    <div class="form-check mx-sm-1 mb-2">
        <input class="form-check-input" type="checkbox" value="yes" name="condition_4" <?php echo $condition_4 ;?> >
        <label class="form-check-label" > Yes</label>
    </div>

    <div class="form-check mx-sm-1 mb-2">
        <input class="form-check-input" type="checkbox" value="no" name="condition_4" <?php echo $condition_4_no?> >
        <label class="form-check-label" >No</label>
    </div>

    <div class="form-group mx-sm-1 mb-2">
        <input type="text" class="form-control" style="width:200px;"  value="<?php echo $condition_4_des?>" name="condition_4_des" >
    </div>

</div>


</div>



<div class="row">

<div class="col-lg-6">
    <p>Have you ever been convicted of any crime or violation of any law, decree, ordinance or regulation by any court or tribunal?</p>
</div>

<div class="col-lg-6 form-inline">

    <div class="form-check mx-sm-1 mb-2">
        <input class="form-check-input" type="checkbox" value="yes" name="condition_5" <?php echo $condition_5 ;?>>
        <label class="form-check-label" > Yes</label>
    </div>

    <div class="form-check mx-sm-1 mb-2">
        <input class="form-check-input" type="checkbox" value="no" name="condition_5" <?php echo $condition_5_no?> >
        <label class="form-check-label" >No</label>
    </div>

    <div class="form-group mx-sm-1 mb-2">
        <input type="text" class="form-control" style="width:200px;"  value="<?php echo $condition_5_des?>" name="condition_5_des" >
    </div>

</div>


</div>



<div class="row">

<div class="col-lg-6">
    <p>Have you ever been seperated from the service in any of the following modes: <br> resignation,retirement,dropped from the rolls, dismissal, termination, end of term, finished contract or phased out(abolition) in the public or private sector?</p>
</div>

<div class="col-lg-6 form-inline">

    <div class="form-check mx-sm-1 mb-2">
        <input class="form-check-input" type="checkbox" value="yes" name="condition_6" <?php echo $condition_6 ;?>>
        <label class="form-check-label" > Yes</label>
    </div>

    <div class="form-check mx-sm-1 mb-2">
        <input class="form-check-input" type="checkbox" value="no" name="condition_6" <?php echo $condition_6_no?> >
        <label class="form-check-label" >No</label>
    </div>

    <div class="form-group mx-sm-1 mb-2">
        <input type="text" class="form-control" style="width:200px;"  value="<?php echo $condition_6_des?>" name="condition_6_des">
    </div>

</div>


</div>



<div class="row">

<div class="col-lg-6">
    <p>Have you ever been a candidate in a national or local election held within the last year(except Barangay election)?</p>
</div>

<div class="col-lg-6 form-inline">

    <div class="form-check mx-sm-1 mb-2">
        <input class="form-check-input" type="checkbox" value="yes" name="condition_7" <?php echo $condition_7 ;?>>
        <label class="form-check-label" > Yes</label>
    </div>

    <div class="form-check mx-sm-1 mb-2">
        <input class="form-check-input" type="checkbox" value="no" name="condition_7" <?php echo $condition_7_no?> >
        <label class="form-check-label" >No</label>
    </div>

    <div class="form-group mx-sm-1 mb-2">
        <input type="text" class="form-control" style="width:200px;"  value="<?php echo $condition_7_des?>" name="condition_7_des" >
    </div>

</div>


</div>



<div class="row">

<div class="col-lg-6">
    <p>Have you acquired the status of an immigrant or permanent resident of another country?</p>
</div>

<div class="col-lg-6 form-inline">

    <div class="form-check mx-sm-1 mb-2">
        <input class="form-check-input" type="checkbox" value="yes" name="condition_8" <?php echo $condition_8 ;?>>
        <label class="form-check-label" > Yes</label>
    </div>

    <div class="form-check mx-sm-1 mb-2">
        <input class="form-check-input" type="checkbox" value="no" name="condition_8" <?php echo $condition_8_no?> >
        <label class="form-check-label" >No</label>
    </div>

    <div class="form-group mx-sm-1 mb-2">
        <input type="text" class="form-control" style="width:200px;"  value="<?php echo $condition_8_des?>" name="condition_8_des" >
    </div>

</div>


</div>



<div class="row">

<div class="col-lg-6">
    <p>Pursuant to: (a) Indigenous People's Act (RA 8371); (b) Magna Carta for Disabled Persons (RA 7277); and (c) Solo Parents Welfare Act of 2000 (RA 8972), please answer the following items:</p>
</div>

<div class="col-lg-6 form-inline">

   

</div>


</div>


<div class="row">

<div class="col-lg-6">
    <p>a.Are you a member of any indigenous group?</p>
</div>

<div class="col-lg-6 form-inline">

    <div class="form-check mx-sm-1 mb-2">
        <input class="form-check-input" type="checkbox" value="yes" name="condition_9" <?php echo $condition_9 ;?>>
        <label class="form-check-label" > Yes</label>
    </div>

    <div class="form-check mx-sm-1 mb-2">
        <input class="form-check-input" type="checkbox" value="no" name="condition_9"  <?php echo $condition_9_no?>>
        <label class="form-check-label" >No</label>
    </div>

    <div class="form-group mx-sm-1 mb-2">
        <input type="text" class="form-control" style="width:200px;"  value="<?php echo $condition_9_des?>" name="condition_9_des" >
    </div>

</div>


</div>


<div class="row">

<div class="col-lg-6">
    <p>b.Are you a person with disability?</p>
</div>

<div class="col-lg-6 form-inline">

    <div class="form-check mx-sm-1 mb-2">
        <input class="form-check-input" type="checkbox" value="yes" name="condition_10" <?php echo $condition_10 ;?> >
        <label class="form-check-label" > Yes</label>
    </div>

    <div class="form-check mx-sm-1 mb-2">
        <input class="form-check-input" type="checkbox" value="no" name="condition_10" <?php echo $condition_10_no?> >
        <label class="form-check-label" >No</label>
    </div>

    <div class="form-group mx-sm-1 mb-2">
        <input type="text" class="form-control" style="width:200px;"  value="<?php echo $condition_10_des?>" name="condition_10_des" >
    </div>

</div>


</div>


<div class="row">

<div class="col-lg-6">
    <p>c.Are you a solo parent?</p>
</div>

<div class="col-lg-6 form-inline">

    <div class="form-check mx-sm-1 mb-2">
        <input class="form-check-input" type="checkbox" value="yes" name="condition_11" <?php echo $condition_11 ;?> >
        <label class="form-check-label" > Yes</label>
    </div>

    <div class="form-check mx-sm-1 mb-2">
        <input class="form-check-input" type="checkbox" value="no" name="condition_11" <?php echo $condition_11_no?> >
        <label class="form-check-label" >No</label>
    </div>

    <div class="form-group mx-sm-1 mb-2">
        <input type="text" class="form-control" style="width:200px;"  value="<?php echo $condition_11_des?>" name="condition_11_des" >
    </div>

</div>


</div>



<div class="row">

<div class="col-lg-6">
    <p>a.within the third degree?</p>
</div>

<div class="col-lg-6 form-inline">

    <div class="form-check mx-sm-1 mb-2">
        <input class="form-check-input" type="checkbox" value="yes" name="condition_12" <?php echo $condition_12 ;?>>
        <label class="form-check-label" > Yes</label>
    </div>

    <div class="form-check mx-sm-1 mb-2">
        <input class="form-check-input" type="checkbox" value="no" name="condition_12" <?php echo $condition_12_no?>>
        <label class="form-check-label" >No</label>
    </div>

    <div class="form-group mx-sm-1 mb-2">
        <input type="text" class="form-control" style="width:200px;"value="<?php echo $condition_12_des?>" name="condition_12_des" >
    </div>

</div>


</div>


                   </div>
                </div>


            </div>
            <div class="container">
              <div class="text-right">
                        <button class="btn m-2" type="button" style="background: #345587;color:#fff;" onclick="openpanel('content-8','spe')" >PREV</button>
                        <button  type ="button"  class="btn m-2" style="background: #345587; color:#fff;" onclick="openpanel('content-10','ref')" >NEXT</button>
                    </div>
              </div>
        </div>
        </div>