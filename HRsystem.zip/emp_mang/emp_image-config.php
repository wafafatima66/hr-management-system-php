<?php

//getting emp id from ajax in pds

if(isset($_POST['emp_id'])){

    $emp_id = $_POST['emp_id'] ; 
    echo $emp_id ; 
}

?>